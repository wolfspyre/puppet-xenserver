puppet-xenserver
================

A module which provides some puppetized sexy on xenserver systems

An example implementation class is provided for a hierified 2.7 setup.